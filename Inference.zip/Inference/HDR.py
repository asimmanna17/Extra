import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from alignhead import *
from network import *


class HDR(nn.Module):
    def __init__(self, n_channel =8, out_channel = 4, embed_dim = 60, depths=[4, 4, 4]):
        super(HDR, self).__init__()
        self.in_channel = n_channel
        self.out_channel = out_channel
        embed_dim = embed_dim
        self.embed_dim = embed_dim
        
        #################### 3. Context-aware Swin Transformer blocks (CTBs)
        depths = depths
        num_heads = [6, 6, 6]
        img_size=128
        patch_size=1
        window_size=8 
        mlp_ratio=4. 
        qkv_bias=True
        qk_scale=None
        drop_rate=0.
        attn_drop_rate=0.
        drop_path_rate=0.1
        norm_layer=nn.LayerNorm
        resi_connection='1conv'
        ape=False
        patch_norm=True
        use_checkpoint=False
        self.num_layers = len(depths)
        self.ape = ape
        self.patch_norm = patch_norm
        self.num_features = embed_dim
        self.mlp_ratio = mlp_ratio

        # split image into non-overlapping patches
        self.patch_embed = PatchEmbed(
            img_size=img_size, patch_size=patch_size, in_chans=embed_dim, embed_dim=embed_dim,
            norm_layer=norm_layer if self.patch_norm else None)
        num_patches = self.patch_embed.num_patches
        patches_resolution = self.patch_embed.patches_resolution
        self.patches_resolution = patches_resolution

        # merge non-overlapping patches into image
        self.patch_unembed = PatchUnEmbed(
            img_size=img_size, patch_size=patch_size, in_chans=embed_dim, embed_dim=embed_dim,
            norm_layer=norm_layer if self.patch_norm else None)

        # absolute position embedding
        if self.ape:
            self.absolute_pos_embed = nn.Parameter(torch.zeros([1, num_patches, embed_dim]))
            trunc_normal_(self.absolute_pos_embed, std=.02)

        self.pos_drop = nn.Dropout(drop_rate)

        # stochastic depth
        dpr = [x.item() for x in np.linspace(0, drop_path_rate, sum(depths))] 

        # build Context-aware Swin Transformer blocks (CTBs)
        self.layers = []
        for i_layer in range(self.num_layers):
            layer = ContextAwareTransformerBlock(dim=embed_dim,
                         input_resolution=(patches_resolution[0],
                                           patches_resolution[1]),
                         depth=depths[i_layer],
                         num_heads=num_heads[i_layer],
                         window_size=window_size,
                         mlp_ratio=self.mlp_ratio,
                         qkv_bias=qkv_bias, qk_scale=qk_scale,
                         drop=drop_rate, attn_drop=attn_drop_rate,
                         drop_path=dpr[sum(depths[:i_layer]):sum(depths[:i_layer + 1])],
                         norm_layer=norm_layer,
                         downsample=None,
                         use_checkpoint=use_checkpoint,
                         img_size=img_size,
                         patch_size=patch_size,
                         resi_connection=resi_connection
                         )
            self.layers.append(layer)
        self.layers = nn.ModuleList(self.layers)
        self.norm = norm_layer(self.num_features)
        
        # build the last conv layer
        self.conv_after_body = nn.Conv2d(self.embed_dim, self.embed_dim, 3, 1, 1)
        self.conv_last = nn.Conv2d(self.embed_dim, self.out_channel, 3, 1, 1)
        self.act_last = nn.Sigmoid()
        self.apply(self._init_weights)

    def forward(self, x, f2):

        # CTBs for HDR reconstruction
        res = self.conv_after_body(self.forward_features(x) + x)
        x = self.conv_last(f2 + res)
        
        output = self.act_last(x)
        return output

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.LayerNorm):
            nn.init.zeros_(m.bias)
            nn.init.ones_(m.weight)

    def no_weight_decay(self):
        return {'absolute_pos_embed'}

    def no_weight_decay_keywords(self):
        return {'relative_position_bias_table'}

    def forward_features(self, x):
        # x [B, embed_dim, h, w]
        x_size = (x.shape[2], x.shape[3])
        x = self.patch_embed(x) # B L C
        if self.ape:
            x = x + self.absolute_pos_embed
        x = self.pos_drop(x)

        for layer in self.layers:
            x = layer(x, x_size)
        x = self.norm(x)  # B L C
        x = self.patch_unembed(x, x_size)
        return x

